package SyntheticsGPTKQL;

public class program {
    public static void main(String[] args) {

        SyntheticsGPTClient client = new SyntheticsGPTClient();
         client.getKQLOutput();
    }
}
