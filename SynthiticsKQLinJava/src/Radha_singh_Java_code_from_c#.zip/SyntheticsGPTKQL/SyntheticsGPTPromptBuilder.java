package SyntheticsGPTKQL;

import jdk.jshell.spi.ExecutionControl;
import java.util.List;

public class SyntheticsGPTPromptBuilder {

    public  List<String> buildPrompts(List<String> tableschema, String userPrompt){

        return tableschema;
    }
    public  void ShowPrompts()
    {

        //throw new ExecutionControl.NotImplementedException();
    }

    public static void main(String[] args) {

    }
}
