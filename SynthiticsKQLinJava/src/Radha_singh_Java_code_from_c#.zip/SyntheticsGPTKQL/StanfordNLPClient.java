package SyntheticsGPTKQL;
import jdk.jshell.spi.ExecutionControl;

import java.util.List;
public abstract class StanfordNLPClient extends NLPProvider {

    public  List<String> getEntities(String userPrompt){
     //   List<String> tableNames = new List<String>();

        return null;
    }

    public   List<String> getIntents(String userPrompt)
    {
       // throw new ExecutionControl.NotImplementedException();
        return null;
    }

    public static void main(String[] args) {

    }
}
