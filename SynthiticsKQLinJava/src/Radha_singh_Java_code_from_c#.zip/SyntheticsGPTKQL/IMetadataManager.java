package SyntheticsGPTKQL;
import java.util.List;
public interface IMetadataManager {
    List<String> getObjectMetadata(List<String> objectName);
}
