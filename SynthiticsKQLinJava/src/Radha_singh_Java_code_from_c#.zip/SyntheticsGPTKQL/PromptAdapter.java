package SyntheticsGPTKQL;

public class PromptAdapter {


    public static PromptBuilder getPromptBuilder() {
        PromptBuilder promptBuilder = new PromptBuilder() {
            @Override
            public void ShowPrompts() {

            }
        };
        return promptBuilder;
    }

    public static void main(String[] args) {

    }
}
