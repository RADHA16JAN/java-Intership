package SyntheticsGPTKQL;

public class Prompt {
    private String role;
    private String instruction;

    public static void main(String[] args) {


    }
}
